package com.example.abc;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;

public class Sample extends Activity {
	 @Override
	    protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.sample_layout);
	      
	    }

}
